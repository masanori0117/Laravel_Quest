<h2 class="text-left">Users</h2>

<div class="row mt-5 mb-5 text-center">
    
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <?php
            
            $movie = $user->movies->last();
            
        ?>
        
<?php if($loop->iteration %3 === 1 && $loop->iteration !== 1 ): ?>
        
</div>
            
<div class="row mt-3 text-center">
                
<?php endif; ?>
        
    <div class="col-4 text-center mb-4">
        
        <span class="pl-5 text-left d-block">
            ＠<?php echo link_to_route('users.show',$user->name,['id'=>$user->id]); ?>

        </span>
        
        <div>
            <?php if($movie): ?>
                <iframe width="290" height="163.125" src="<?php echo e('https://www.youtube.com/embed/'.$movie->url); ?>?controls=1&loop=1&playlist=<?php echo e($movie->url); ?>" frameborder="0"></iframe>
            <?php else: ?>
                <iframe width="290" height="163.125" src="https://www.youtube.com/embed/" frameborder="0"></iframe>
            <?php endif; ?>
        </div>
        
        <p>
            <?php if(isset($movie->comment)): ?>
                <?php echo e($movie->comment); ?>

            <?php endif; ?>
        </p>
        
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php echo e($users->links('pagination::bootstrap-4')); ?>

