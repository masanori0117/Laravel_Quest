<footer class="mt-5">
    <nav class="navbar navbar-light bg-light justify-content-center">
        <div class="navbar-brand m-0">© QuestAcademia, All rights reserved.</div>
    </nav>
</footer>