<?php $__env->startSection('content'); ?>


<h1><?php echo e($user->name); ?></h1>

<ul class="nav nav-tabs nav-justified mt-5 mb-2">
    <li class="nav-item nav-link <?php echo e(Request::is('users/' . $user->id) ? 'active' : ''); ?>"><a href="<?php echo e(route('users.show',['id'=>$user->id])); ?>">動 画<br><div class="badge badge-secondary"><?php echo e($count_movies); ?></div></a></li>
    <li class="nav-item nav-link"><a href="" class="">フォロワー<br><div class="badge badge-secondary"></div></a></li>
    <li class="nav-item nav-link"><a href="" class="">フォロー中<br><div class="badge badge-secondary"></div></a></li>
</ul>

<?php echo $__env->make('movies.movies', ['movies' => $movies], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>