<div class="movies row mt-5 text-center">
    
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($loop->iteration % 3 == 1 && $loop->iteration != 1): ?>
    
            <?php
                echo '</div><div class="row text-center mt-3">';
            ?>
        
        <?php endif; ?>
    
            <div class="col-lg-4 mb-5">

                <div class="movie text-left d-inline-block">

                    <div>
                       <?php if($movie): ?>
                            <iframe width="290" height="163.125" src="<?php echo e('https://www.youtube.com/embed/'.$movie->url); ?>?controls=1&loop=1&playlist=<?php echo e($movie->url); ?>" frameborder="0"></iframe>
                        <?php else: ?>
                            <iframe width="290" height="163.125" src="https://www.youtube.com/embed/" frameborder="0"></iframe>
                        <?php endif; ?>
                    </div>
                    
                    <p>
                        <?php if(isset($movie->comment)): ?>
                            <?php echo e($movie->comment); ?>

                        <?php endif; ?>
                    </p>
                    
                    <?php if(Auth::id() == $movie->user_id): ?>
                        <?php echo Form::open(['route' => ['movies.destroy', $movie->id], 'method' => 'delete']); ?>

                            <?php echo Form::submit('この動画を削除する？', ['class' => 'button btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>

                </div>
                
            </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php echo e($movies->render('pagination::bootstrap-4')); ?>